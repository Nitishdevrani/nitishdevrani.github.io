from controller import Robot
import math

MAX_SPEED = 12.3  
WHEELS_DISTANCE = 0.325  
DIAMETER = 0.19  
RADIUS = DIAMETER / 2  

SAFE_DISTANCE = 0.42 + 0.01  # Safe distance of lidar + variable of accuracy
LIDAR_OFFSET = 0.08  # Distance of lidar sensor from the center of the robot

robot = Robot()

timestep = int(robot.getBasicTimeStep())

leftMotor = robot.getDevice('left wheel')
rightMotor = robot.getDevice('right wheel')

leftMotor.setPosition(float('inf'))
rightMotor.setPosition(float('inf'))
leftMotor.setVelocity(0.0)
rightMotor.setVelocity(0.0)

lidar = robot.getDevice('Sick LMS 291')
lidar.enable(60)  
lidar.enablePointCloud()  

def wait(timing):
    current_time = robot.getTime()
    while robot.getTime() - current_time < timing:
        if robot.step(timestep) == -1:
            break
def move_forward():
    curr_speed = 0.40 * MAX_SPEED
    leftMotor.setVelocity(curr_speed)
    rightMotor.setVelocity(curr_speed)

def stop():
    leftMotor.setVelocity(0)
    rightMotor.setVelocity(0)
           
def turn(degree = 90):
    angle_rad = math.radians(degree)
    slow_speed =  0.30 * MAX_SPEED

    turning_speed = (2 * slow_speed * RADIUS) / WHEELS_DISTANCE 

    slow_turn_time = abs(angle_rad)/turning_speed
    
    if degree > 0:
        leftMotor.setVelocity(-slow_speed)
        rightMotor.setVelocity(slow_speed)
    elif degree < 0:
        leftMotor.setVelocity(slow_speed)
        rightMotor.setVelocity(-slow_speed)
    else:
        return
    wait(slow_turn_time)
    leftMotor.setVelocity(0)
    rightMotor.setVelocity(0)
                
def move(distance):

    while robot.step(timestep) != -1:
        lidar_data = lidar.getRangeImage()
        front_distance = lidar_data[len(lidar_data) // 2]
    
        print('final dis',front_distance)
    
        if front_distance <= SAFE_DISTANCE:
            stop()  # Stop the robot if within the safe distance
            print("Robot stopped at safe distance.")
            final = lidar.getRangeImage()[len(lidar.getRangeImage()) // 2]
            print(final)
            break
        else:
            move_forward()

# Main loop:
while robot.step(timestep) != -1:
    wait(1)
    first_scan = lidar.getRangeImage()
    front_closest = min(first_scan)
    angle_front = first_scan.index(front_closest)
    print("first closest",front_closest)

    turn(180)
    wait(1)
    last_scan = lidar.getRangeImage()
    back_closest = min(last_scan)
    angle_back = last_scan.index(back_closest)
    print("back closest",back_closest)
    
    print(front_closest,back_closest)
    if front_closest <= back_closest:
        closest_point = front_closest
        angle = 180 + (90 - angle_front)
    else:
        closest_point = back_closest
        angle = 90 - angle_back
        
    angle = (angle + 180) % 360 - 180
    print("Turn to:",angle)
    
    turn(angle)
    wait(1)
    move(closest_point)
    
    

    break

# Enter exit cleanup code if needed